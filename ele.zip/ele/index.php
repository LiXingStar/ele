<?php
// 单入口
define('CSS_PATH','/ele/static/css');
define('JS_PATH','/ele/static/js');
define('IMG_PATH','/ele/static/images');



include 'libs/Router.php';
include 'libs/smarty/Smarty.class.php';
include 'libs/main.php';
include 'libs/function.php';
include 'libs/db.php';
Router::run();
// index.php/login/init







