<?php

class Router
{
    static function run()
    {
        if (!isset($_SERVER['PATH_INFO']) || $_SERVER['PATH_INFO'] == '/') {
            $model = 'login';
            $method = 'init';
        } else {
            $path = substr($_SERVER['PATH_INFO'], 1);
            $arr = explode('/', $path);
            // category/add
            $model = $arr[0];
            $method = isset($arr[1]) && $arr[1] ? $arr[1] : 'init';
        }

        // app/model/category.php
        if(file_exists('app/model/'.$model.'.php')){
           include 'app/model/'.$model.'.php';
           if(class_exists($model)){
               $obj = new $model();
               if(method_exists($obj,$method)){
                   $obj->$method();
               }else{
                   $title = $method.'方法不存在';
                   include 'app/views/404.html';
               }
           }else{
               $title = $model.'类不存在';
               include 'app/views/404.html';
           }
        }else{
            $title = $model.'.php文件不存在';
            include 'app/views/404.html';
        }



    }

}


