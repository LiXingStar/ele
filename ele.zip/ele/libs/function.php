<?php

class unit
{

    function __construct()
    {
        $this->str = '';
    }

    //  string  boolean int float  array object  null  resource
    function getCate($mysql, $parentid, $tablename, $flag, $currentid = null)
    {
        // $currentid 父级栏目
        static $pid = null;
        if ($currentid) {
            $sql = "select pid from $tablename where cid=$currentid";
            $pid = $mysql->query($sql)->fetch_assoc()['pid'];
        }
        $sql = "select * from $tablename where pid=$parentid";
        $data = $mysql->query($sql);
        $flag++;
        while ($row = $data->fetch_assoc()) {
            $str = str_repeat('-', $flag);
            // $row['id']
            if ($row['cid'] == $pid) {
                $this->str .= "<option value=\"{$row['cid']}\" selected>{$str}{$row['cname']}</option>";
            } else {
                $this->str .= "<option value=\"{$row['cid']}\">{$str}{$row['cname']}</option>";
            }
            $this->getCate($mysql, $row['cid'], $tablename, $flag,$currentid=null);

        }
        return $this->str;
    }

    function getParent($mysql,$parentid,$tablename,$flag,$currentid){
        static $pid = null;
        $sql = "select * from $tablename where pid=$parentid";
        $data = $mysql->query($sql);
        $flag++;
        while ($row = $data->fetch_assoc()) {
            $str = str_repeat('-', $flag);
            // $row['id']
            if ($row['cid'] == $currentid) {
                $this->str .= "<option value=\"{$row['cid']}\" selected>{$str}{$row['cname']}</option>";
            } else {
                $this->str .= "<option value=\"{$row['cid']}\">{$str}{$row['cname']}</option>";
            }
            $this->getParent($mysql, $row['cid'], $tablename, $flag,$currentid);

        }
        return $this->str;
    }


}