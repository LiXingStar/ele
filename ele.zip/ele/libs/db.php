<?php
// $db =  new db('')
// $db->mysql
class db{
    public $tablename;
    public $mysql;
    public $wherestr;
    function __construct($tablename)
    {
        $this->tablename = $tablename;
        $this->config();
    }
    public function config(){
       $this->mysql = new mysqli('localhost','root','','ele',3306);
       if($this->mysql->connect_errno){
           echo '数据库连接失败'.$this->mysql->connect_errno;
       }
       $this->mysql->query('set names utf8');
    }
    function insert($str){
        if(is_string($str) && strpos($str,'nsert')){
           $sql = $str;
        }else{
           $sql = "insert into $this->tablename (";
           $keyarr = array_keys($str);
           for($i=0;$i<count($keyarr);$i++){
               $sql .= $keyarr[$i].',';
           }
           $sql =  substr($sql,0,-1) . ") values (";

           foreach ($str as $key=>$value){
               $sql .= "'{$value}',";
           }
            $sql =  substr($sql,0,-1) . ")";
        }
        $this->mysql->query($sql);
        return $this->mysql->affected_rows;

    }
    function query($str){
       $data =  $this->mysql->query($str)->fetch_all(MYSQLI_ASSOC);
       return $data;
    }
    function delete($str){
        $sql = "delete from $this->tablename where $str";
        $this->mysql->query($sql);
        return $this->mysql->affected_rows;
    }
    function update($str){
        if(is_string($str) && strpos($str,'pdate')){
            $sql =$str;
        }else{
            $sql ="update $this->tablename set ";
            foreach ($str as $k=>$v){
                $sql .= $k .'='."'$v',";
            }
            $sql = substr($sql,0,-1);
            $sql .=$this->wherestr;
        }
        $this->mysql->query($sql);
        return  $this->mysql->affected_rows;
    }
    function where($str){
        $this->wherestr = "where " . $str;
        return $this;
    }
}