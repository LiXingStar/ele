$(function(){
   let submit = $(':submit');

   let uploadThumb = new Upload({
       url:'/ele/index.php/upload/upload',
       inputObj:'#thumbBtn',
       imgObj:'#sthumb',
       progressObj:'.progress-bar'
   });
   
   let uploadImg = new Upload({
      url:'/ele/index.php/upload/upload',
      inputObj:'#simgBtn',
      imgObj:'#sImg',
      progressObj:'.progressImg'
   }) ;


   uploadThumb.upload(function(msg){
       $('input[name=sthumb]').val(msg);
   });
   uploadImg.upload(function(msg){
       $('input[name=simg]').val(msg);
   })
   ///////////////////////////////////////////
   submit.on('click',function(e){
       e.preventDefault();
       let formdata = new FormData($('form')[0]);
       $.ajax({
           url:'/ele/index.php/manageshop/insert',
           type:'post',
           data:formdata,
           processData:false,
           contentType:false,
           dataType:'text',
           success:function(msg){
               if(msg === 'success'){
                   alert('店铺添加成功');
                   location.href = '/ele/index.php/manageshop/query';
               }else if(msg === 'fail'){
                   alert('店铺添加失败');
               }
           }
       })
   })
    //////////////////////////////////////////////



})