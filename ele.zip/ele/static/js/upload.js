class Upload {
    constructor({url, inputObj, progressObj, imgObj}) {
        this.url = url;
        if (typeof inputObj === 'string') {
            this.inputObj = document.querySelector(inputObj);
        } else {
            this.inputObj = inputObj;
        }

        if (typeof  progressObj === 'string') {
            this.progressObj = document.querySelector(progressObj);
        } else {
            this.progressObj = progressObj;
        }

        if (typeof  imgObj === 'string') {
            this.imgObj = document.querySelector(imgObj);
        } else {
            this.imgObj = imgObj;
        }

        this.imgType = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        this.size = 1024 * 1024 * 2;

        this.uploadstart = function () {
        }

    }

    upload(callback) {
        this.callback = callback;
        if (!this.url) {
            alert('请输入上传路径');
            return;
        }
        this._getContent();
    }

    _getContent() {
        let that = this;
        this.inputObj.onchange = function () {
            that.file = this.files[0];
            console.log(that.file);
            let reader = new FileReader();
            reader.readAsDataURL(that.file);
            reader.onload = function (e) {
                that.imgObj.src = e.target.result
            };
            if (that._check()) {
                that._uploadFile();
            }
        }

    }

    _check() {
        // 类型
        let type = this.file.type.split('/')[1];
        if (!this.imgType.includes(type)) {
            alert('上传文件类型错误');
            return false;
        }
        // 大小
        if (this.file.size >= this.size) {
            alert('上传文件过大');
            return false;
        }
        return true;
    }

    _uploadFile () {
        let xml = new XMLHttpRequest();
        let formdata = new FormData();
        let that = this;
        formdata.append('file', this.file);


        xml.upload.onloadstart = function () {
            that.uploadstart();
        }
        xml.upload.onprogress = function (e) {
            let bili = e.loaded / e.total * 100 + '%';
            that.progressObj.style.width = bili;
            that.progressObj.innerText = bili;
        }
        xml.onload = function () {
            if (that.callback) {
                that.callback(xml.response);
            }
        }
        xml.open('POST', this.url);
        xml.send(formdata);
    }

}