$(function () {
    let submit = $('button:submit');
    let uplaod = $('input:file');
    let thumb = $('img#thumb');
    let cid = location.search.split('=')[1];
    let progressbar = $('.progress-bar');
    // 图片上传
    uplaod.on('change', function (e) {
        let file = this.files[0];
        let reader = new FileReader();
        let parent = $(this).parent();
        reader.readAsDataURL(file);
        reader.onload = function(ev){
            let src=ev.target.result;
            thumb.attr('src',src);
        }
        let formdata =new FormData();
        formdata.append('file',file);
        $.ajax({
            url:'/ele/index.php/managecate/upload',
            type:'post',
            data:formdata,
            contentType:false,
            processData:false,
            dataType:'text',
            success:function(msg){
                $('input:hidden').val(msg);
            }
        })
    });
    //
    submit.on('click', function () {
        // let data = $('form').serialize();
        let formdata = new FormData($('form')[0]);
        formdata.append('cid',cid);
        $.ajax({
            url: '/ele/index.php/managecate/update',
            type:'post',
            contentType:false,
            processData:false,
            data: formdata,
            success: function (msg) {
               if(msg == 'success'){
                   location.href = '/ele/index.php/managecate/query';
               }else if(msg=='fail'){
                   location.href = '/ele/index.php/managecate/query';
               }
            }
        });
        return false;
    })

});