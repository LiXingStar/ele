$(function(){
    let submit = $('input:submit');
    submit.on('click',function(e){
        e.preventDefault();
        let arr = $('form').serializeArray();
        let str = '';
        arr.forEach(element=>{
            str += `${element.name}=${element.value}&`;
        });
        str = str.slice(0,-1);

        $.ajax({
            url:'login/check',
            type:'post',
            data:str,
            success:function(msg){
               if(msg == 'success'){
                   location.href = '/ele/index.php/managecate/add';
               }else if(msg == 'fail'){
                   alert('密码错误');
               }else if(msg == 'noexist'){
                   alert('用户名不存在');
               }
            }
        })


    })

})