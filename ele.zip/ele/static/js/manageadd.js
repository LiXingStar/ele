$(function () {
    let submit = $('button:submit');
    // let uplaod = $('input:file');
    // 图片上传
    /*uplaod.on('change', function (e) {
        let file = this.files[0];
        let reader = new FileReader();
        let parent = $(this).parent();
        reader.readAsDataURL(file);
        reader.onload = function(ev){
            let src=ev.target.result;
            $('<img>').attr('src',src).css({width:80}).insertAfter(parent);
        }
        //
        let formdata =new FormData();
        formdata.append('file',file);
        $.ajax({
            url:'/ele/index.php/managecate/upload',
            type:'post',
            data:formdata,
            contentType:false,
            processData:false,
            dataType:'text',
            success:function(msg){
                $('input:hidden').val(msg);
            }
        })
    });*/
   let upload = new Upload({
       url:'/ele/index.php/managecate/upload',
       inputObj:'input[type=file]',
       progressObj:'.progress-bar',
       imgObj:'#thumb'
   });

   upload.uploadstart = function(){
      submit.attr('disabled',true)
   };
   upload.upload(function(msg){
       submit.removeAttr('disabled');
       $('input:hidden').val(msg)
   });

    //
    submit.on('click', function () {
        let data = $('form').serialize();
        $.ajax({
            url: '/ele/index.php/managecate/insert',
            data: data,
            success: function (msg) {
               if(msg == 'success'){
                   location.href = '/ele/index.php/managecate/query';
               }else if(msg=='fail'){}
            }
        });
        return false;
    })

});