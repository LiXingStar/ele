$(function () {
    $('tbody').on('click', 'a.border-red', function () {
        let id = $(this).attr('id');
        let tr = $(this).closest('tr');
        $.ajax({
            url: '/ele/index.php/manageshop/delete',
            data: {id},
            success: function (msg) {
                if (msg === 'success') {
                    tr.remove();
                } else if (msg === 'fail') {
                    alert('数据删除失败');
                }
            }

        })
    })

});