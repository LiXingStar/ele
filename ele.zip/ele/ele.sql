-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2018-06-12 09:42:16
-- 服务器版本： 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ele`
--

-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE `category` (
  `cid` int(10) NOT NULL,
  `cname` varchar(255) NOT NULL,
  `cimg` varchar(255) NOT NULL,
  `pid` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `category`
--

INSERT INTO `category` (`cid`, `cname`, `cimg`, `pid`) VALUES
(2, '快餐', '/ele/static/upload/18-06-05/1528185275.png', 0),
(3, '火锅', '/ele/static/upload/18-06-05/1528185523.png', 0),
(8, '披萨', '/ele/static/upload/18-06-11/1528686965.png', 0),
(9, '面食', '/ele/static/upload/18-06-11/1528707720.png', 0),
(7, '美食', '/ele/static/upload/18-06-11/1528684767.png', 0),
(10, '简餐便当', '/ele/static/upload/18-06-11/1528684767.png', 7),
(11, '面食粥店', '/ele/static/upload/18-06-11/1528684767.png', 7),
(12, '小吃炸串', '/ele/static/upload/18-06-11/1528684767.png', 7),
(13, '香锅冒菜', '/ele/static/upload/18-06-11/1528684767.png', 7),
(14, '地方特色', '/ele/static/upload/18-06-11/1528684767.png', 7),
(15, '汉堡披萨', '/ele/static/upload/18-06-11/1528684767.png', 7),
(16, '清式西餐', '/ele/static/upload/18-06-11/1528684767.png', 7);

-- --------------------------------------------------------

--
-- 表的结构 `manage`
--

CREATE TABLE `manage` (
  `id` int(10) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `manage`
--

INSERT INTO `manage` (`id`, `username`, `password`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- 表的结构 `shop`
--

CREATE TABLE `shop` (
  `sid` int(10) UNSIGNED NOT NULL,
  `sname` varchar(255) NOT NULL,
  `sthumb` varchar(255) NOT NULL,
  `sdesc` varchar(255) NOT NULL,
  `snotice` varchar(255) NOT NULL,
  `simg` varchar(255) NOT NULL,
  `cid` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `shop`
--

INSERT INTO `shop` (`sid`, `sname`, `sthumb`, `sdesc`, `snotice`, `simg`, `cid`) VALUES
(2, '黄焖鸡米饭', '/ele/static/upload/18-06-12/1528772350.jpeg', '好吃不贵', '新用户立减14元', '/ele/static/upload/18-06-12/1528772427.png', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `manage`
--
ALTER TABLE `manage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`sid`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `category`
--
ALTER TABLE `category`
  MODIFY `cid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- 使用表AUTO_INCREMENT `manage`
--
ALTER TABLE `manage`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `shop`
--
ALTER TABLE `shop`
  MODIFY `sid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
