<?php

class managecate extends main
{
    function __construct()
    {
        parent::__construct();
        $this->db = new db('category');
    }

    function add()
    {
        $db = new db('category');
        $obj = new unit();
        $str = $obj->getCate($db->mysql, 0, 'category', 0);
        $this->smarty->assign('str', $str);
        $this->smarty->display('views/managecate.html');
    }

    function insert()
    {
        $pid = $_GET['pid'];
        $cname = $_GET['cname'];
        $cimg = $_GET['cimg'];
        $sql = "insert into category (pid,cname,cimg) values ('$pid','$cname','$cimg')";
        $db = new db('category');
        $rows = $db->insert($sql);
        if ($rows == 1) {
            echo 'success';
        } else {
            echo 'fail';
        }
    }

    function upload()
    {
        $file = $_FILES['file'];
        if (is_uploaded_file($file['tmp_name'])) {
            // 判断upload文件
            if (!file_exists('static/upload')) {
                mkdir('static/upload');
            }
            $time = date('y-m-d', time());
            if (!file_exists('static/upload/' . $time)) {
                mkdir('static/upload/' . $time);
            }
            // 哪个  移动  哪里 名字
            $name = time();
            // 字符串 -> 数组
            $type = explode('.', $file['name'])[1];
            $filename = $name . '.' . $type;
            $path = 'static/upload/' . $time . '/' . $filename;
            move_uploaded_file($file['tmp_name'], $path);
            $imgurl = '/ele/' . $path;
            echo $imgurl;
        }
    }

    function query()
    {
        $data = $this->db->query("select * from category");
        $this->smarty->assign('data', $data);
        $this->smarty->display('views/catequery.html');
    }

    function delete()
    {
        $cid = $_GET['id'];
        $rows = $this->db->delete("cid=$cid");
        if ($rows === 1) {
            $this->query();
        } else if ($rows < 0) {
            $this->query();
        }
    }

    function updatequery()
    {
        $cid = $_GET['cid'];
        $catetree = new unit();
        $str = $catetree->getCate($this->db->mysql, 0, $this->db->tablename, 0, $cid);

        $data = $this->db->query("select * from {$this->db->tablename} where cid = $cid")[0];
        $this->smarty->assign('str', $str);
        $this->smarty->assign('data', $data);
        $this->smarty->display('views/cateupdate.html');
    }

    function update()
    {
        $data =  $_POST;
        $cid = $data['cid'];
        unset($data['cid']);
        $rows = $this->db->where("cid=$cid")->update($data);
    }
}