<?php
class login extends main {
    function __construct()
    {
        parent::__construct();
    }
    function init(){
       $this->smarty->display('views/login.html');
    }
    function check(){
        $mysql =  new mysqli('localhost','root','','ele',3306);
        if($mysql->connect_errno){
            echo '数据库连接失败' .$mysql->connect_errno;
            exit();
        }
        $username = $_POST['username'];
        $password = md5($_POST['password']);

        $sql = "select * from manage where username='$username'";

        $data = $mysql->query($sql)->fetch_assoc();
        if(is_array($data)){
            if($password == $data['password']){
                echo 'success';
            }else{
                echo 'fail';
            }
        }else{
            echo 'noexist';
        }

    }

}