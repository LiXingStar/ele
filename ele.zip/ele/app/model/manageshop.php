<?php
class manageshop extends main{
    function __construct()
    {
        parent::__construct();
        $this->db = new db('shop');
    }
    function init(){
        $db =  new db('category');
        $obj = new unit();
        $str = $obj->getCate($db->mysql,0,$db->tablename,0);
        $this->smarty->assign('str',$str);
        $this->smarty->display('views/shopadd.html');
    }
    function insert(){
        $data = $_POST;
        $rows = $this->db->insert($data);
        if($rows === 1){
            echo 'success';
        }else{
            echo 'fail';
        }
    }

    function query(){
        $data = $this->db->query("select shop.* , category.cname from shop,category where shop.cid=category.cid");
        $this->smarty->assign('data',$data);
        $this->smarty->display('views/shopquery.html');

    }
    function update(){

    }
    function delete(){
       $id = $_GET['id'];
       $rows = $this->db->delete("sid=$id");
       if($rows === 1){
           echo 'success';
       }else{
           echo 'fail';
       }
    }
    function updatequery(){
        $sid = $_GET['sid'];
        $cid = $_GET['cid'];
        $obj = new unit();
        $str = $obj->getParent($this->db->mysql,0,'category',0,$cid);

        $data = $this->db->query("select * from shop where sid=$sid")[0];

        $this->smarty->assign('str',$str);
        $this->smarty->assign('data',$data);
        $this->smarty->display('views/shopupdate.html');
    }


}