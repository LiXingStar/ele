<?php

class upload
{
    function upload()
    {
        $file = $_FILES['file'];
        if (is_uploaded_file($file['tmp_name'])) {
            // 判断upload文件
            if (!file_exists('static/upload')) {
                mkdir('static/upload');
            }
            $time = date('y-m-d', time());
            if (!file_exists('static/upload/' . $time)) {
                mkdir('static/upload/' . $time);
            }
            // 哪个  移动  哪里 名字
            $name = time();
            // 字符串 -> 数组
            $type = explode('.', $file['name'])[1];
            $filename = $name . '.' . $type;
            $path = 'static/upload/' . $time . '/' . $filename;
            move_uploaded_file($file['tmp_name'], $path);
            $imgurl = '/ele/' . $path;
            echo $imgurl;
        }
    }
}