<?php
/* Smarty version 3.1.32, created on 2018-06-12 01:13:48
  from 'C:\wamp\www\ele\app\views\leftnav.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1f1e4c884cf6_69767793',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '260b569ce39d3ca590f090ed2d6bb6d4e4d9bb13' => 
    array (
      0 => 'C:\\wamp\\www\\ele\\app\\views\\leftnav.html',
      1 => 1528764841,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b1f1e4c884cf6_69767793 (Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="leftnav">
    <div class="leftnav-title"><strong><span class="icon-list"></span>菜单列表</strong></div>
    <h2><span class="icon-pencil-square-o"></span>栏目管理</h2>
    <ul>
        <li><a href="/ele/index.php/managecate/add"><span class="icon-caret-right"></span>添加栏目</a></li>
        <li><a href="/ele/index.php/managecate/query"><span class="icon-caret-right"></span>查看栏目</a></li>
    </ul>
    <h2><span class="icon-pencil-square-o"></span>店铺管理</h2>
    <ul>
        <li><a href="/ele/index.php/manageshop/init"><span class="icon-caret-right"></span>添加店铺</a></li>
        <li><a href="/ele/index.php/manageshop/query"><span class="icon-caret-right"></span>查看店铺</a></li>
    </ul>
</div>
<?php echo '<script'; ?>
 type="text/javascript">
    $(function(){

        $(".leftnav h2").click(function(){
            $(this).next().slideToggle(200);
            $(this).toggleClass("on");
        })
        $(".leftnav ul li a").click(function(){
            $("#a_leader_txt").text($(this).text());
            $(".leftnav ul li a").removeClass("on");
            $(this).addClass("on");
        })
    });
<?php echo '</script'; ?>
>
<ul class="bread">
    <li><a href="" target="right" class="icon-home"> 首页</a></li>
    <li><a href="##" id="a_leader_txt">网站信息</a></li>
    <li><b>当前语言：</b><span style="color:red;">中文</php></span>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;切换语言：<a href="##">中文</a> &nbsp;&nbsp;<a href="##">英文</a> </li>
</ul><?php }
}
