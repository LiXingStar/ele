<?php
/* Smarty version 3.1.32, created on 2018-06-11 02:21:19
  from 'C:\wamp\www\ele\app\views\catequery.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1ddc9f5a4d14_92255369',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2e1f80c2a4325a25a6cf1f764a65abcf61abdf26' => 
    array (
      0 => 'C:\\wamp\\www\\ele\\app\\views\\catequery.html',
      1 => 1528683153,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:views/header.html' => 1,
    'file:views/leftnav.html' => 1,
  ),
),false)) {
function content_5b1ddc9f5a4d14_92255369 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:views/header.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:views/leftnav.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="admin">
    <div class="panel admin-panel">
        <div class="panel-head"><strong class="icon-reorder"> 分类列表</strong></div>
        <table class="table table-hover text-center">
            <tr>
                <th width="5%">ID</th>
                <th width="15%">分类名称</th>
                <th width="10%">分类图片</th>
                <th width="10%">PID</th>
                <th width="10%">操作</th>
            </tr>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['v']->value['cid'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['v']->value['cname'];?>
</td>
                <td><img src="<?php echo $_smarty_tpl->tpl_vars['v']->value['cimg'];?>
" alt=""></td>
                <td><?php echo $_smarty_tpl->tpl_vars['v']->value['pid'];?>
</td>
                <td><div class="button-group"> <a class="button border-main" href="/ele/index.php/managecate/updatequery?cid=<?php echo $_smarty_tpl->tpl_vars['v']->value['cid'];?>
"><span class="icon-edit"></span> 修改</a> <a class="button border-red" href="/ele/index.php/managecate/delete?id=<?php echo $_smarty_tpl->tpl_vars['v']->value['cid'];?>
" ><span class="icon-trash-o"></span> 删除</a> </div></td>
            </tr>
           <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </table>
    </div>
</div><?php }
}
