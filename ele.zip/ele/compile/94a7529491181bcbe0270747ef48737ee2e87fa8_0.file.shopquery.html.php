<?php
/* Smarty version 3.1.32, created on 2018-06-12 09:31:05
  from 'C:\wamp\www\ele\app\views\shopquery.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1f92d9b8a6e8_23496285',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '94a7529491181bcbe0270747ef48737ee2e87fa8' => 
    array (
      0 => 'C:\\wamp\\www\\ele\\app\\views\\shopquery.html',
      1 => 1528795816,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:views/header.html' => 1,
    'file:views/leftnav.html' => 1,
  ),
),false)) {
function content_5b1f92d9b8a6e8_23496285 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:views/header.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:views/leftnav.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="admin">
    <div class="panel admin-panel">
        <div class="panel-head"><strong class="icon-reorder"> 分类列表</strong></div>
        <table class="table table-hover text-center">
            <tr>
                <th width="5%">ID</th>
                <th width="15%">店铺名称</th>
                <th width="10%">店铺缩略图</th>
                <th width="10%">描述</th>
                <th width="10%">公告</th>
                <th width="10%">背景</th>
                <th width="10%">所属分类</th>
                <th width="10%">操作</th>
            </tr>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['v']->value['sid'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['v']->value['sname'];?>
</td>
                <td><img src="<?php echo $_smarty_tpl->tpl_vars['v']->value['sthumb'];?>
" alt="" width="50"></td>
                <td><?php echo $_smarty_tpl->tpl_vars['v']->value['sdesc'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['v']->value['snotice'];?>
</td>
                <td><img src="<?php echo $_smarty_tpl->tpl_vars['v']->value['simg'];?>
" alt="" width="50"></td>
                <td><?php echo $_smarty_tpl->tpl_vars['v']->value['cname'];?>
</td>
                <td><div class="button-group"> <a class="button border-main" href="/ele/index.php/manageshop/updatequery?sid=<?php echo $_smarty_tpl->tpl_vars['v']->value['sid'];?>
&cid=<?php echo $_smarty_tpl->tpl_vars['v']->value['cid'];?>
"><span class="icon-edit"></span> 修改</a> <a class="button border-red" id="<?php echo $_smarty_tpl->tpl_vars['v']->value['sid'];?>
"><span class="icon-trash-o"></span> 删除</a> </div></td>
            </tr>
           <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </table>
    </div>
</div>
<?php echo '<script'; ?>
 src="<?php echo JS_PATH;?>
/shopquery.js"><?php echo '</script'; ?>
><?php }
}
